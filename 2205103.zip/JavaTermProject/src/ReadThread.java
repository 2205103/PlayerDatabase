
/*
Only ReadThread for each Club
* */

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ReadThread extends Thread {

    private LoginController loginController;
    //private volatile boolean running = true; // Flag to control the thread
    private TableView<Player> tableView;
    private TableView<Player> main;
    private SocketWrapper socketWrapper;
    private PlayerTableController controller;
    String clubname;

    public ReadThread(SocketWrapper socketWrapper, TableView<Player> tableView,LoginController loginController,String clubname,TableView<Player>main) {
        this.socketWrapper = socketWrapper;
        this.loginController=loginController;
        this.tableView = tableView;
        this.clubname=clubname;
        this.main=main;
    }

    @Override
    public void run() {
        try {
            while (true) {
                // Read the list of players from the server
                Object o = socketWrapper.read();

                if( "MainList".equalsIgnoreCase(((Request) o).getTag()))  //It means the server has sent the clubs ALL PLAYER LIST
                {
                    ObservableList<Player> playerList = FXCollections.observableArrayList(filter2(((Request) o).getPlayerList()));
                    System.out.print("Server sends ALL PLAYER LIST to ");
                    {
                        Platform.runLater(() -> {
                            // Clear the table temporarily to force a refresh
                            main.getItems().clear();

                            // Assign the updated list
                            main.setItems(playerList);

                            // Force the table to refresh (if clearing doesn't work alone)
                            main.refresh();
                        });
                    }
                }
                else {
                    System.out.println("Server sends SALABLE PLAYERS LIST"); //It means the Server has sent SALABLE PLAYERS list
                    synchronized (o) {
                        ObservableList<Player> playerList = FXCollections.observableArrayList(filter(((Request) o).getPlayerList()));

                        Platform.runLater(() -> {
                            // Clear the table temporarily to force a refresh
                            tableView.getItems().clear();

                            // Assign the updated list
                            tableView.setItems(playerList);

                            // Force the table to refresh (if clearing doesn't work alone)
                            tableView.refresh();
                        });
                    }
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Method to stop the thread safely
    public void setTableView(TableView<Player> tableView) {
        this.tableView=tableView;
    }

    private List<Player> filter(List<Player> playerList)
    {
        List<Player> result = new ArrayList<>();
        // Iterate through the values of the map
        synchronized (playerList) {
            for (Player player : playerList) {
                if (!player.getClub().equalsIgnoreCase(clubname)) {
                    result.add(player);
                }
            }
        }
        return result;
    }

    private List<Player> filter2(List<Player> playerList)
    {
        List<Player> result = new ArrayList<>();
        // Iterate through the values of the map
        synchronized (playerList) {
            for (Player player : playerList) {
                if (player.getClub().equalsIgnoreCase(clubname)) {
                    result.add(player);
                }
            }
        }
        return result;
    }
}
