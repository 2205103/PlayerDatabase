import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import java.io.File;

public class Main extends Application {

    Stage stage;
    private MediaPlayer mediaPlayer;

    @Override
    public void start(Stage primaryStage) {
        try {
            // Load the FXML file
            this.stage = primaryStage;
            FXMLLoader loader = new FXMLLoader(getClass().getResource("fx.fxml"));
            Scene scene = new Scene(loader.load(), 600, 640);

            // Set up the stage
            primaryStage.setTitle("Cricket Player Database");
            primaryStage.setScene(scene);
            primaryStage.show();

            // Load and play audio
            playAudio("1.mp3");

            Control ctrl = loader.getController();
            ctrl.setObject(this);
            // new PlayerServer();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void playAudio(String fileName) {
        try {
            String filePath = new File(fileName).toURI().toString();
            Media media = new Media(filePath);
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
        } catch (Exception e) {
            System.out.println("Error loading audio file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void nextScence(Scene newScene) {
        stage.setScene(newScene);
        stage.show();
    }
}
